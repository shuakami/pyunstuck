"""PyUnstuck - Your lifesaver for frozen Python scripts"""

__version__ = "0.1.0" 